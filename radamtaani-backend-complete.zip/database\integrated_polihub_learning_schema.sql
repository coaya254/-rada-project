-- ============================================
-- INTEGRATED POLIHUB + LEARNING DATABASE SCHEMA
-- This schema integrates Politics/Civic Education with Learning Modules
-- Shared database: rada_ke (same as RadaAppClean)
-- ============================================

SET FOREIGN_KEY_CHECKS = 0;

-- ============================================
-- 1. POLITICIANS & POLITICAL DATA
-- ============================================

-- Enhanced Politicians table with full US political data
CREATE TABLE IF NOT EXISTS politicians (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(255) NOT NULL,
    nickname VARCHAR(100),
    title VARCHAR(100),
    party ENUM('Democrat', 'Republican', 'Independent', 'Other', 'UDA', 'ODM', 'ANC', 'Wiper') NOT NULL,
    chamber ENUM('Senate', 'House', 'Governor', 'Cabinet', 'Executive', 'Parliament', 'County') NOT NULL,
    state VARCHAR(100),
    district VARCHAR(100),
    constituency VARCHAR(255),
    county VARCHAR(255),
    image_url VARCHAR(500),
    biography TEXT,
    date_of_birth DATE,
    years_in_office INT DEFAULT 0,
    office_address TEXT,
    phone VARCHAR(50),
    email VARCHAR(255),
    website_url VARCHAR(500),
    twitter_handle VARCHAR(100),
    instagram_handle VARCHAR(100),
    facebook_url VARCHAR(500),
    wikipedia_url VARCHAR(500),
    status ENUM('active', 'inactive', 'former') DEFAULT 'active',

    -- Legacy fields for compatibility
    position VARCHAR(255),
    politician_id VARCHAR(100) UNIQUE,
    rating DECIMAL(3,2) DEFAULT 0.00,
    total_votes INT DEFAULT 0,
    is_draft BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_politician_id (politician_id),
    INDEX idx_name (full_name),
    INDEX idx_party (party),
    INDEX idx_chamber (chamber),
    INDEX idx_state (state),
    INDEX idx_status (status),
    INDEX idx_politicians_party_state (party, state)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Politician Committees
CREATE TABLE IF NOT EXISTS politician_committees (
    id INT AUTO_INCREMENT PRIMARY KEY,
    politician_id INT NOT NULL,
    committee_name VARCHAR(255) NOT NULL,
    role ENUM('member', 'chair', 'ranking_member', 'vice_chair') DEFAULT 'member',
    start_date DATE,
    end_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (politician_id) REFERENCES politicians(id) ON DELETE CASCADE,
    INDEX idx_politician_committee (politician_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Politician Key Issues
CREATE TABLE IF NOT EXISTS politician_key_issues (
    id INT AUTO_INCREMENT PRIMARY KEY,
    politician_id INT NOT NULL,
    issue_name VARCHAR(255) NOT NULL,
    description TEXT,
    priority_level ENUM('high', 'medium', 'low') DEFAULT 'medium',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (politician_id) REFERENCES politicians(id) ON DELETE CASCADE,
    INDEX idx_politician_issues (politician_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Politician Statistics
CREATE TABLE IF NOT EXISTS politician_stats (
    id INT AUTO_INCREMENT PRIMARY KEY,
    politician_id INT NOT NULL UNIQUE,
    profile_views INT DEFAULT 0,
    total_comments INT DEFAULT 0,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    FOREIGN KEY (politician_id) REFERENCES politicians(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Politician Career (compatibility with existing schema)
CREATE TABLE IF NOT EXISTS politician_career (
    id INT AUTO_INCREMENT PRIMARY KEY,
    politician_id INT NOT NULL UNIQUE,
    education TEXT,
    previous_positions TEXT,
    achievements TEXT,
    controversies TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    FOREIGN KEY (politician_id) REFERENCES politicians(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 2. VOTING RECORDS & BILLS
-- ============================================

CREATE TABLE IF NOT EXISTS bills (
    id INT AUTO_INCREMENT PRIMARY KEY,
    bill_number VARCHAR(100) NOT NULL UNIQUE,
    title VARCHAR(500) NOT NULL,
    short_title VARCHAR(255),
    description TEXT,
    full_text_url VARCHAR(500),
    status ENUM('introduced', 'committee', 'floor', 'passed', 'failed', 'enacted') DEFAULT 'introduced',
    chamber ENUM('house', 'senate', 'joint') NOT NULL,
    sponsor_id INT,
    introduced_date DATE,
    last_action_date DATE,
    category VARCHAR(100),
    tags JSON,
    summary TEXT,
    views_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    FOREIGN KEY (sponsor_id) REFERENCES politicians(id) ON DELETE SET NULL,
    INDEX idx_bill_number (bill_number),
    INDEX idx_status (status),
    INDEX idx_chamber (chamber),
    INDEX idx_sponsor (sponsor_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS votes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    bill_id INT NOT NULL,
    politician_id INT NOT NULL,
    vote_type ENUM('yea', 'nay', 'present', 'not_voting') NOT NULL,
    vote_date DATE NOT NULL,
    chamber ENUM('house', 'senate') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (bill_id) REFERENCES bills(id) ON DELETE CASCADE,
    FOREIGN KEY (politician_id) REFERENCES politicians(id) ON DELETE CASCADE,
    UNIQUE KEY unique_vote (bill_id, politician_id),
    INDEX idx_politician_votes (politician_id),
    INDEX idx_bill_votes (bill_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bill_cosponsors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    bill_id INT NOT NULL,
    politician_id INT NOT NULL,
    cosponsor_type ENUM('original', 'added') DEFAULT 'added',
    date_cosponsored DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (bill_id) REFERENCES bills(id) ON DELETE CASCADE,
    FOREIGN KEY (politician_id) REFERENCES politicians(id) ON DELETE CASCADE,
    UNIQUE KEY unique_cosponsor (bill_id, politician_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Legacy voting records table (for compatibility)
CREATE TABLE IF NOT EXISTS politician_voting_records (
    id INT AUTO_INCREMENT PRIMARY KEY,
    politician_id INT NOT NULL,
    bill_name VARCHAR(255) NOT NULL,
    vote VARCHAR(50) NOT NULL,
    date DATE NOT NULL,
    category VARCHAR(100),
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (politician_id) REFERENCES politicians(id) ON DELETE CASCADE,
    INDEX idx_voting_politician (politician_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 3. CIVIC EDUCATION TOPICS
-- ============================================

CREATE TABLE IF NOT EXISTS civic_topics (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    slug VARCHAR(255) UNIQUE NOT NULL,
    subtitle TEXT,
    category VARCHAR(100),
    icon_emoji VARCHAR(10) DEFAULT '📚',
    difficulty_level ENUM('beginner', 'intermediate', 'advanced') DEFAULT 'beginner',
    read_time_minutes INT DEFAULT 10,
    badge_type VARCHAR(50),
    color_gradient VARCHAR(100),
    intro_text TEXT,
    created_by_admin_id VARCHAR(36),
    views_count INT DEFAULT 0,
    published BOOLEAN DEFAULT FALSE,
    published_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_slug (slug),
    INDEX idx_category (category),
    INDEX idx_civic_topics_published (published, published_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS topic_sections (
    id INT AUTO_INCREMENT PRIMARY KEY,
    topic_id INT NOT NULL,
    section_type ENUM('key_point', 'example', 'explanation', 'summary') DEFAULT 'explanation',
    heading VARCHAR(255),
    content TEXT,
    order_index INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (topic_id) REFERENCES civic_topics(id) ON DELETE CASCADE,
    INDEX idx_topic_sections (topic_id, order_index)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS topic_key_points (
    id INT AUTO_INCREMENT PRIMARY KEY,
    topic_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    content TEXT,
    order_index INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (topic_id) REFERENCES civic_topics(id) ON DELETE CASCADE,
    INDEX idx_topic_key_points (topic_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS topic_examples (
    id INT AUTO_INCREMENT PRIMARY KEY,
    topic_id INT NOT NULL,
    example_text TEXT NOT NULL,
    order_index INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (topic_id) REFERENCES civic_topics(id) ON DELETE CASCADE,
    INDEX idx_topic_examples (topic_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 4. BLOG/DISCOURSE SYSTEM
-- ============================================

CREATE TABLE IF NOT EXISTS blog_posts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(500) NOT NULL,
    slug VARCHAR(255) UNIQUE NOT NULL,
    excerpt TEXT,
    featured_image_url VARCHAR(500),
    category VARCHAR(100),
    author_name VARCHAR(255),
    author_role VARCHAR(100),
    author_avatar_emoji VARCHAR(10) DEFAULT '👤',
    read_time_minutes INT DEFAULT 5,
    status ENUM('draft', 'published', 'archived') DEFAULT 'draft',
    views_count INT DEFAULT 0,
    comments_count INT DEFAULT 0,
    created_by_admin_id VARCHAR(36),
    published_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_slug (slug),
    INDEX idx_status (status),
    INDEX idx_category (category),
    INDEX idx_blog_posts_category_published (category, published_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS blog_content (
    id INT AUTO_INCREMENT PRIMARY KEY,
    post_id INT NOT NULL UNIQUE,
    intro_text TEXT,
    conclusion_text TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (post_id) REFERENCES blog_posts(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS blog_sections (
    id INT AUTO_INCREMENT PRIMARY KEY,
    post_id INT NOT NULL,
    heading VARCHAR(255) NOT NULL,
    order_index INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (post_id) REFERENCES blog_posts(id) ON DELETE CASCADE,
    INDEX idx_blog_sections (post_id, order_index)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS blog_paragraphs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    section_id INT NOT NULL,
    content TEXT NOT NULL,
    order_index INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (section_id) REFERENCES blog_sections(id) ON DELETE CASCADE,
    INDEX idx_blog_paragraphs (section_id, order_index)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS blog_tags (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    slug VARCHAR(100) NOT NULL UNIQUE,
    usage_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_tag_slug (slug)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS post_tags (
    post_id INT NOT NULL,
    tag_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (post_id, tag_id),
    FOREIGN KEY (post_id) REFERENCES blog_posts(id) ON DELETE CASCADE,
    FOREIGN KEY (tag_id) REFERENCES blog_tags(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS blog_authors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    display_name VARCHAR(255) NOT NULL,
    role_title VARCHAR(100),
    bio TEXT,
    avatar_emoji VARCHAR(10) DEFAULT '👤',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 5. COMMENTS SYSTEM (Anonymous)
-- ============================================

CREATE TABLE IF NOT EXISTS comments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    post_id INT NOT NULL,
    parent_comment_id INT NULL,
    pseudonym VARCHAR(100) NOT NULL,
    email VARCHAR(255),
    content TEXT NOT NULL,
    ip_address_hash VARCHAR(64),
    status ENUM('pending', 'approved', 'flagged', 'hidden', 'deleted') DEFAULT 'pending',
    flagged_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    approved_at TIMESTAMP NULL,
    approved_by_admin_id VARCHAR(36),

    FOREIGN KEY (post_id) REFERENCES blog_posts(id) ON DELETE CASCADE,
    FOREIGN KEY (parent_comment_id) REFERENCES comments(id) ON DELETE CASCADE,
    INDEX idx_comments_post_status (post_id, status),
    INDEX idx_comments_created (created_at DESC),
    INDEX idx_parent_comment (parent_comment_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS comment_flags (
    id INT AUTO_INCREMENT PRIMARY KEY,
    comment_id INT NOT NULL,
    reason ENUM('spam', 'offensive', 'misinformation', 'harassment', 'other') NOT NULL,
    description TEXT,
    ip_address_hash VARCHAR(64),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (comment_id) REFERENCES comments(id) ON DELETE CASCADE,
    INDEX idx_comment_flags (comment_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 6. NEWSLETTER SYSTEM
-- ============================================

CREATE TABLE IF NOT EXISTS newsletter_subscribers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    subscribed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    confirmed BOOLEAN DEFAULT FALSE,
    confirmation_token VARCHAR(100) UNIQUE,
    unsubscribed_at TIMESTAMP NULL,
    ip_address_hash VARCHAR(64),

    INDEX idx_email (email),
    INDEX idx_confirmed (confirmed)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS email_campaigns (
    id INT AUTO_INCREMENT PRIMARY KEY,
    subject VARCHAR(255) NOT NULL,
    content TEXT,
    sent_to_count INT DEFAULT 0,
    open_rate DECIMAL(5,2) DEFAULT 0.00,
    click_rate DECIMAL(5,2) DEFAULT 0.00,
    sent_at TIMESTAMP NULL,
    sent_by_admin_id VARCHAR(36),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 7. ANALYTICS & METRICS
-- ============================================

CREATE TABLE IF NOT EXISTS page_views (
    id INT AUTO_INCREMENT PRIMARY KEY,
    page_type ENUM('home', 'politician', 'topic', 'post', 'bill', 'about') NOT NULL,
    page_id INT,
    session_id VARCHAR(100),
    referrer_url VARCHAR(500),
    device_type ENUM('mobile', 'tablet', 'desktop') DEFAULT 'desktop',
    browser VARCHAR(100),
    country VARCHAR(100),
    state VARCHAR(100),
    viewed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_page_views_date (viewed_at),
    INDEX idx_page_type (page_type, page_id),
    INDEX idx_session (session_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS daily_stats (
    id INT AUTO_INCREMENT PRIMARY KEY,
    date DATE NOT NULL UNIQUE,
    total_page_views INT DEFAULT 0,
    unique_visitors INT DEFAULT 0,
    total_posts_viewed INT DEFAULT 0,
    total_topics_viewed INT DEFAULT 0,
    total_politicians_viewed INT DEFAULT 0,
    new_comments INT DEFAULT 0,
    new_subscribers INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_date (date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS content_analytics (
    id INT AUTO_INCREMENT PRIMARY KEY,
    content_type ENUM('post', 'topic', 'politician', 'bill') NOT NULL,
    content_id INT NOT NULL,
    date DATE NOT NULL,
    views INT DEFAULT 0,
    unique_views INT DEFAULT 0,
    avg_time_on_page INT DEFAULT 0,
    bounce_rate DECIMAL(5,2) DEFAULT 0.00,
    comments_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    UNIQUE KEY unique_content_date (content_type, content_id, date),
    INDEX idx_content_analytics (content_type, content_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS politician_analytics (
    id INT AUTO_INCREMENT PRIMARY KEY,
    politician_id INT NOT NULL,
    date DATE NOT NULL,
    profile_views INT DEFAULT 0,
    unique_views INT DEFAULT 0,
    comments_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (politician_id) REFERENCES politicians(id) ON DELETE CASCADE,
    UNIQUE KEY unique_politician_date (politician_id, date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS trending_content (
    id INT AUTO_INCREMENT PRIMARY KEY,
    content_type ENUM('post', 'topic', 'politician', 'bill') NOT NULL,
    content_id INT NOT NULL,
    title VARCHAR(500),
    emoji_icon VARCHAR(10),
    engagement_score DECIMAL(10,2) DEFAULT 0.00,
    trending_since TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_calculated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    UNIQUE KEY unique_trending (content_type, content_id),
    INDEX idx_engagement (engagement_score DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 8. SEARCH FUNCTIONALITY
-- ============================================

CREATE TABLE IF NOT EXISTS search_queries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    query_text VARCHAR(255) NOT NULL,
    search_type ENUM('politicians', 'topics', 'bills', 'posts', 'all') DEFAULT 'all',
    results_count INT DEFAULT 0,
    result_clicked BOOLEAN DEFAULT FALSE,
    clicked_result_type VARCHAR(50),
    clicked_result_id INT,
    session_id VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_query_text (query_text),
    INDEX idx_search_type (search_type),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS popular_searches (
    id INT AUTO_INCREMENT PRIMARY KEY,
    query_text VARCHAR(255) NOT NULL UNIQUE,
    search_count INT DEFAULT 0,
    last_searched_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_search_count (search_count DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 9. SITE CONTENT & SETTINGS
-- ============================================

CREATE TABLE IF NOT EXISTS site_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) NOT NULL UNIQUE,
    setting_value JSON,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    updated_by_admin_id VARCHAR(36)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS trending_topics (
    id INT AUTO_INCREMENT PRIMARY KEY,
    topic_name VARCHAR(255) NOT NULL,
    emoji_icon VARCHAR(10),
    display_order INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_by_admin_id VARCHAR(36),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_display_order (display_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS quick_searches (
    id INT AUTO_INCREMENT PRIMARY KEY,
    search_text VARCHAR(255) NOT NULL,
    icon_emoji VARCHAR(10),
    color_gradient VARCHAR(100),
    display_order INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS quotes_of_day (
    id INT AUTO_INCREMENT PRIMARY KEY,
    quote_text TEXT NOT NULL,
    author VARCHAR(255),
    is_active BOOLEAN DEFAULT TRUE,
    display_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS team_members (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    role VARCHAR(100),
    bio TEXT,
    avatar_emoji VARCHAR(10) DEFAULT '👤',
    display_order INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS awards (
    id INT AUTO_INCREMENT PRIMARY KEY,
    award_name VARCHAR(255) NOT NULL,
    organization VARCHAR(255),
    year_received INT,
    description TEXT,
    display_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS faqs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    question VARCHAR(500) NOT NULL,
    answer TEXT NOT NULL,
    category VARCHAR(100),
    display_order INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS about_sections (
    id INT AUTO_INCREMENT PRIMARY KEY,
    section_type ENUM('mission', 'values', 'story', 'impact', 'team', 'contact') NOT NULL,
    title VARCHAR(255),
    content TEXT,
    display_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 10. MODERATION SYSTEM
-- ============================================

CREATE TABLE IF NOT EXISTS moderation_queue (
    id INT AUTO_INCREMENT PRIMARY KEY,
    item_type ENUM('comment', 'post', 'user_report') NOT NULL,
    item_id INT NOT NULL,
    status ENUM('pending', 'reviewing', 'approved', 'rejected') DEFAULT 'pending',
    assigned_to_admin_id VARCHAR(36),
    reviewed_at TIMESTAMP NULL,
    review_notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_status (status),
    INDEX idx_item (item_type, item_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS blocked_ips (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ip_address_hash VARCHAR(64) NOT NULL UNIQUE,
    reason TEXT,
    blocked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    blocked_by_admin_id VARCHAR(36),
    expires_at TIMESTAMP NULL,

    INDEX idx_ip_hash (ip_address_hash)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS spam_filters (
    id INT AUTO_INCREMENT PRIMARY KEY,
    filter_type ENUM('keyword', 'pattern', 'domain', 'email') NOT NULL,
    filter_value VARCHAR(500) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by_admin_id VARCHAR(36)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 11. EVENTS SYSTEM
-- ============================================

CREATE TABLE IF NOT EXISTS events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    event_type ENUM('town_hall', 'debate', 'protest', 'rally', 'registration_drive', 'hearing', 'workshop', 'other') NOT NULL,
    start_datetime DATETIME NOT NULL,
    end_datetime DATETIME,
    location VARCHAR(255),
    address TEXT,
    city VARCHAR(100),
    state VARCHAR(100),
    zip VARCHAR(20),
    virtual_link VARCHAR(500),
    organizer VARCHAR(255),
    politician_id INT NULL,
    created_by_admin_id VARCHAR(36),
    views_count INT DEFAULT 0,
    published BOOLEAN DEFAULT FALSE,
    published_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    FOREIGN KEY (politician_id) REFERENCES politicians(id) ON DELETE SET NULL,
    INDEX idx_start_datetime (start_datetime),
    INDEX idx_event_type (event_type),
    INDEX idx_published (published)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 12. NEWS & MEDIA (Legacy Support)
-- ============================================

CREATE TABLE IF NOT EXISTS news_sources (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    rss_url VARCHAR(500) NOT NULL,
    website_url VARCHAR(500),
    source_tier ENUM('tier_1a_international', 'tier_1b_kenyan', 'tier_2_regional', 'tier_3_local') NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    last_checked TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    success_rate DECIMAL(5,2) DEFAULT 100.00,

    INDEX idx_source_tier (source_tier),
    INDEX idx_is_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS news_articles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    article_id VARCHAR(100) UNIQUE NOT NULL,
    headline VARCHAR(500) NOT NULL,
    content_summary TEXT,
    original_url VARCHAR(500) NOT NULL,
    source_id INT NOT NULL,
    published_date TIMESTAMP,
    collected_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    content_hash VARCHAR(64) UNIQUE,
    is_duplicate BOOLEAN DEFAULT FALSE,
    duplicate_of_article_id VARCHAR(100),

    FOREIGN KEY (source_id) REFERENCES news_sources(id),
    INDEX idx_article_id (article_id),
    INDEX idx_content_hash (content_hash),
    INDEX idx_published_date (published_date),
    INDEX idx_is_duplicate (is_duplicate)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS politician_news (
    id INT AUTO_INCREMENT PRIMARY KEY,
    politician_id INT NOT NULL,
    article_id INT NOT NULL,
    relevance_score DECIMAL(3,2) DEFAULT 1.00,
    mention_type ENUM('primary', 'secondary', 'mentioned') DEFAULT 'mentioned',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (politician_id) REFERENCES politicians(id) ON DELETE CASCADE,
    FOREIGN KEY (article_id) REFERENCES news_articles(id) ON DELETE CASCADE,
    UNIQUE KEY unique_politician_article (politician_id, article_id),
    INDEX idx_politician_id (politician_id),
    INDEX idx_relevance_score (relevance_score)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS politician_wikipedia (
    id INT AUTO_INCREMENT PRIMARY KEY,
    politician_id INT NOT NULL UNIQUE,
    wikipedia_url VARCHAR(500),
    biography_summary TEXT,
    education TEXT,
    career_background TEXT,
    family_info TEXT,
    last_wikipedia_update TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    attribution_note TEXT DEFAULT 'Content from Wikipedia under CC BY-SA license',

    FOREIGN KEY (politician_id) REFERENCES politicians(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 13. LEGACY TABLES FOR COMPATIBILITY
-- ============================================

CREATE TABLE IF NOT EXISTS politician_documents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    politician_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    type VARCHAR(50) NOT NULL,
    date DATE NOT NULL,
    description TEXT,
    file_url VARCHAR(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (politician_id) REFERENCES politicians(id) ON DELETE CASCADE,
    INDEX idx_documents_politician (politician_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS politician_timeline (
    id INT AUTO_INCREMENT PRIMARY KEY,
    politician_id INT NOT NULL,
    date DATE NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    type VARCHAR(50) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (politician_id) REFERENCES politicians(id) ON DELETE CASCADE,
    INDEX idx_timeline_politician (politician_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS politician_commitments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    politician_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    status VARCHAR(50) NOT NULL DEFAULT 'pending',
    category VARCHAR(100),
    date_made DATE NOT NULL,
    deadline DATE,
    progress INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    FOREIGN KEY (politician_id) REFERENCES politicians(id) ON DELETE CASCADE,
    INDEX idx_commitments_politician (politician_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- ============================================
-- CREATE VIEWS FOR COMMON QUERIES
-- ============================================

CREATE OR REPLACE VIEW v_active_politicians AS
SELECT
    id, full_name, nickname, title, party, chamber, state,
    image_url, biography, status, created_at
FROM politicians
WHERE status = 'active'
ORDER BY full_name;

CREATE OR REPLACE VIEW v_published_blog_posts AS
SELECT
    bp.*,
    bc.intro_text,
    bc.conclusion_text
FROM blog_posts bp
LEFT JOIN blog_content bc ON bp.id = bc.post_id
WHERE bp.status = 'published'
ORDER BY bp.published_at DESC;

CREATE OR REPLACE VIEW v_published_civic_topics AS
SELECT *
FROM civic_topics
WHERE published = TRUE
ORDER BY views_count DESC, published_at DESC;

-- ============================================
-- SAMPLE DATA INSERT (Optional)
-- ============================================

-- Note: This will be added in a separate file for sample data

SELECT 'Database schema created successfully!' as status;
