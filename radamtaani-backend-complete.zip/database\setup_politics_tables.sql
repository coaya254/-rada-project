-- Political Information Hub Database Setup
-- This script creates all necessary tables for the automated political news and information system

-- 1. Politicians Table
CREATE TABLE IF NOT EXISTS politicians (
    id INT AUTO_INCREMENT PRIMARY KEY,
    politician_id VARCHAR(100) UNIQUE NOT NULL, -- e.g., "william_ruto_001"
    name VARCHAR(255) NOT NULL,
    position VARCHAR(255) NOT NULL,
    party VARCHAR(255),
    constituency VARCHAR(255),
    county VARCHAR(255),
    wikipedia_url VARCHAR(500),
    profile_created TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    INDEX idx_politician_id (politician_id),
    INDEX idx_name (name),
    INDEX idx_position (position)
);

-- 2. News Sources Table
CREATE TABLE IF NOT EXISTS news_sources (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    rss_url VARCHAR(500) NOT NULL,
    website_url VARCHAR(500),
    source_tier ENUM('tier_1a_international', 'tier_1b_kenyan', 'tier_2_regional') NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    last_checked TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    success_rate DECIMAL(5,2) DEFAULT 100.00,
    INDEX idx_source_tier (source_tier),
    INDEX idx_is_active (is_active)
);

-- 3. News Articles Table
CREATE TABLE IF NOT EXISTS news_articles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    article_id VARCHAR(100) UNIQUE NOT NULL,
    headline VARCHAR(500) NOT NULL,
    content_summary TEXT,
    original_url VARCHAR(500) NOT NULL,
    source_id INT NOT NULL,
    published_date TIMESTAMP,
    collected_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    content_hash VARCHAR(64) UNIQUE, -- For duplicate detection
    is_duplicate BOOLEAN DEFAULT FALSE,
    duplicate_of_article_id VARCHAR(100),
    FOREIGN KEY (source_id) REFERENCES news_sources(id),
    INDEX idx_article_id (article_id),
    INDEX idx_content_hash (content_hash),
    INDEX idx_published_date (published_date),
    INDEX idx_is_duplicate (is_duplicate)
);

-- 4. Politician News Connections Table
CREATE TABLE IF NOT EXISTS politician_news (
    id INT AUTO_INCREMENT PRIMARY KEY,
    politician_id INT NOT NULL,
    article_id INT NOT NULL,
    relevance_score DECIMAL(3,2) DEFAULT 1.00, -- How relevant is this article to the politician
    mention_type ENUM('primary', 'secondary', 'mentioned') DEFAULT 'mentioned',
    FOREIGN KEY (politician_id) REFERENCES politicians(id),
    FOREIGN KEY (article_id) REFERENCES news_articles(id),
    UNIQUE KEY unique_politician_article (politician_id, article_id),
    INDEX idx_politician_id (politician_id),
    INDEX idx_relevance_score (relevance_score)
);

-- 5. Story Groups Table (For grouping similar articles)
CREATE TABLE IF NOT EXISTS story_groups (
    id INT AUTO_INCREMENT PRIMARY KEY,
    group_id VARCHAR(100) UNIQUE NOT NULL,
    story_title VARCHAR(500) NOT NULL,
    story_summary TEXT,
    event_date DATE,
    story_type ENUM('policy_announcement', 'public_appearance', 'investigation', 'achievement', 'other') DEFAULT 'other',
    credibility_level ENUM('maximum', 'high', 'medium', 'low') DEFAULT 'low',
    source_count INT DEFAULT 0,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_group_id (group_id),
    INDEX idx_credibility_level (credibility_level),
    INDEX idx_event_date (event_date)
);

-- 6. Story Group Articles Table (Links articles to story groups)
CREATE TABLE IF NOT EXISTS story_group_articles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    story_group_id INT NOT NULL,
    article_id INT NOT NULL,
    added_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (story_group_id) REFERENCES story_groups(id),
    FOREIGN KEY (article_id) REFERENCES news_articles(id),
    UNIQUE KEY unique_story_article (story_group_id, article_id),
    INDEX idx_story_group_id (story_group_id)
);

-- 7. Wikipedia Data Table
CREATE TABLE IF NOT EXISTS politician_wikipedia (
    id INT AUTO_INCREMENT PRIMARY KEY,
    politician_id INT NOT NULL,
    wikipedia_url VARCHAR(500),
    biography_summary TEXT,
    education TEXT,
    career_background TEXT,
    family_info TEXT,
    last_wikipedia_update TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    attribution_note TEXT DEFAULT 'Content from Wikipedia under CC BY-SA license',
    FOREIGN KEY (politician_id) REFERENCES politicians(id),
    UNIQUE KEY unique_politician_wiki (politician_id),
    INDEX idx_politician_id (politician_id)
);

-- 8. System Health Log Table
CREATE TABLE IF NOT EXISTS system_health_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    check_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    rss_feeds_status ENUM('healthy', 'warning', 'error') DEFAULT 'healthy',
    database_status ENUM('healthy', 'warning', 'error') DEFAULT 'healthy',
    wikipedia_status ENUM('healthy', 'warning', 'error') DEFAULT 'healthy',
    articles_collected_today INT DEFAULT 0,
    errors_encountered TEXT,
    INDEX idx_check_date (check_date)
);

-- Insert sample data for testing
INSERT INTO politicians (politician_id, name, position, party, constituency) VALUES
('william_ruto_001', 'William Ruto', 'President', 'UDA', 'Sugoi'),
('musalia_mudavadi_001', 'Musalia Mudavadi', 'Prime Cabinet Secretary', 'ANC', 'Sabatia'),
('rigathi_gachagua_001', 'Rigathi Gachagua', 'Deputy President', 'UDA', 'Mathira');

INSERT INTO news_sources (name, rss_url, website_url, source_tier) VALUES
('BBC Africa', 'https://feeds.bbci.co.uk/news/world/africa/rss.xml', 'https://www.bbc.com/news/world/africa', 'tier_1a_international'),
('Daily Nation', 'https://www.nation.co.ke/news/rss', 'https://www.nation.co.ke', 'tier_1b_kenyan'),
('The Standard', 'https://www.standardmedia.co.ke/rss', 'https://www.standardmedia.co.ke', 'tier_1b_kenyan');

-- Create indexes for performance
CREATE INDEX idx_news_articles_source_date ON news_articles(source_id, published_date);
CREATE INDEX idx_politician_news_relevance ON politician_news(politician_id, relevance_score);
CREATE INDEX idx_story_groups_credibility_date ON story_groups(credibility_level, event_date);
